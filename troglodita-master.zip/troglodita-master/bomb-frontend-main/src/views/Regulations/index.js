export {default} from './Regulations';
