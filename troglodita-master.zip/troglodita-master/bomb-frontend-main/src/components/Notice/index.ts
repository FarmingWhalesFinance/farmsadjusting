export {default} from './Notice';
