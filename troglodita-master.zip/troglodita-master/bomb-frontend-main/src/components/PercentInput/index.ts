export {default} from './PercentInput';
